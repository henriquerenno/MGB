#include <immintrin.h>
#include <math.h>

void dis_vec_(double *ZTABBAS, double *Hfl, int *CELJUS, double *dxart, float *SRIO, double *ZTABJUS, float *SRIOJUS, double *DBRIO, double *Q2fl, double *nMan, double *g, double *dtflood, float *QJ2, double *HflJUS, int *NC)
{
    int i, j;
	__m512d z1, HflVecPD, y1, z2, y2, dxartVecPD, dxartMILVecPD, DSRIOVecPD, dxflowVecPD, HflJUSVecPD, DSRIOJUSVecPD;
	__m512d max_y2y1, max_z2z1, sub_max_zy, zeroPD, hflowVecPD, bflowVecPD, Q2flVecPD, q0VecPD, sub_y1y2, neg_sub_y1y2, SflowVecPD;
	__m512d neg1VecPD, gVecPD, dtfloodVecPD, iniDISCALCVecPD, DISCALCVecPD, qNumVecPD, nManVecPD, qDenomVecPD, q0absVecPD;
	__m512d hflowPowVecPD, powerVecPD, onePD, qVecPD, milPD, twoPD, DSRIOMILVecPD, five2neg4VecPD, qoldVecPD;
	__m256 hflowVecPS, SRIOVecPS, SRIOJUSVecPS, qVecPS, milPS, five2neg4VecPS;
	__m256i iCJusVecIPS, neg1VecIPS;
	__mmask8 iCJusMask, hflowMask;
	float powerPS;
	double powerPD;
	int NCVec;

	neg1VecIPS = _mm256_set1_epi32(-1);
	neg1VecPD = _mm512_set1_pd(-1.0);
	dxartVecPD = _mm512_set1_pd(*dxart);
	five2neg4VecPS = _mm256_set1_ps(0.0005);
	//five2neg4VecPD = _mm512_set1_pd(0.0005);
	five2neg4VecPD = _mm512_cvtps_pd(five2neg4VecPS);
	zeroPD = _mm512_set1_pd(0.0);
	gVecPD = _mm512_set1_pd(*g);
	dtfloodVecPD = _mm512_set1_pd(*dtflood);
	iniDISCALCVecPD = _mm512_mul_pd(gVecPD, dtfloodVecPD);
	powerPS = 10.0/3.0;
	powerPD = (double)(powerPS);
	powerVecPD = _mm512_set1_pd(powerPD);
	onePD = _mm512_set1_pd(1.0);
	twoPD = _mm512_set1_pd(2.0);
	milPS = _mm256_set1_ps(1000.0);
	//milPD = _mm512_set1_pd(1000.0);
	milPD = _mm512_cvtps_pd(milPS);
	dxartMILVecPD = _mm512_mul_pd(dxartVecPD, milPD);
	dxartVecPD = _mm512_mul_pd(five2neg4VecPD, dxartVecPD);
	dxartVecPD = _mm512_mul_pd(dxartVecPD, milPD);
	NCVec = *NC-(*NC)%8;
    for(i = 0;i < NCVec;i+=8)
	{
		// Bottom level and water level of IC catchment:
		z1 = _mm512_load_pd(ZTABBAS+i);
		HflVecPD = _mm512_load_pd(Hfl+i);
		y1 = _mm512_add_pd(HflVecPD, z1);

	    // Bottom level and water level of downstream IC catchment:
		iCJusVecIPS = _mm256_load_epi32(CELJUS+i);

		SRIOVecPS = _mm256_load_ps(SRIO+i);
		SRIOVecPS = _mm256_mul_ps(SRIOVecPS, milPS);
        DSRIOMILVecPD = _mm512_cvtps_pd(SRIOVecPS);
		// if iCJus == -1
		iCJusMask = _mm256_cmpeq_epi32_mask(iCJusVecIPS, neg1VecIPS);
		z2 = _mm512_maskz_sub_pd(iCJusMask, z1, dxartVecPD);
		y2 = _mm512_maskz_sub_pd(iCJusMask, y1, dxartVecPD);
		dxflowVecPD = _mm512_maskz_add_pd(iCJusMask, DSRIOMILVecPD, dxartMILVecPD);
		// else
		iCJusMask = _mm256_cmpneq_epi32_mask(iCJusVecIPS, neg1VecIPS);
		z2 = _mm512_mask_load_pd(z2, iCJusMask, ZTABJUS+i);
		HflJUSVecPD = _mm512_load_pd(HflJUS+i);
		y2 = _mm512_mask_add_pd(y2, iCJusMask, HflJUSVecPD, z2);
		SRIOJUSVecPS = _mm256_load_ps(SRIOJUS+i);
		SRIOJUSVecPS = _mm256_mul_ps(SRIOJUSVecPS, milPS);
        DSRIOJUSVecPD = _mm512_cvtps_pd(SRIOJUSVecPS);
		dxflowVecPD = _mm512_mask_add_pd(dxflowVecPD, iCJusMask, DSRIOMILVecPD, DSRIOJUSVecPD);

		dxflowVecPD = _mm512_div_pd(dxflowVecPD, twoPD);

		// Calculates the hflow variable:
		max_y2y1 = _mm512_max_pd(y2, y1);
		max_z2z1 = _mm512_max_pd(z2, z1);
		sub_max_zy = _mm512_sub_pd(max_y2y1, max_z2z1);
		hflowVecPD = _mm512_max_pd(sub_max_zy, zeroPD);
		hflowVecPS = _mm512_cvtpd_ps(hflowVecPD);
        hflowVecPD = _mm512_cvtps_pd(hflowVecPS);

		// River width
		bflowVecPD = _mm512_load_pd(DBRIO+i);

		// Flow in the last time-step
		Q2flVecPD = _mm512_load_pd(Q2fl+i);
		q0VecPD = _mm512_div_pd(Q2flVecPD, bflowVecPD);

		// Water table slope:
		sub_y1y2 = _mm512_sub_pd(y1, y2);
		neg_sub_y1y2 = _mm512_mul_pd(neg1VecPD, sub_y1y2);
		SflowVecPD = _mm512_div_pd(neg_sub_y1y2, dxflowVecPD);

		// Calculates flow from Inertial equation (m2/s) for each IC:
		hflowMask = _mm512_cmplt_pd_mask(zeroPD, hflowVecPD);
		DISCALCVecPD = _mm512_maskz_mul_pd(hflowMask, iniDISCALCVecPD, hflowVecPD);
		qNumVecPD = _mm512_maskz_mul_pd(hflowMask, DISCALCVecPD, SflowVecPD);
		qNumVecPD = _mm512_maskz_sub_pd(hflowMask, q0VecPD, qNumVecPD);
		nManVecPD = _mm512_load_pd(nMan+i);
		qDenomVecPD = _mm512_maskz_mul_pd(hflowMask, DISCALCVecPD, nManVecPD);
		qDenomVecPD = _mm512_maskz_mul_pd(hflowMask, qDenomVecPD, nManVecPD);
		q0absVecPD = _mm512_abs_pd(q0VecPD);
		qDenomVecPD = _mm512_maskz_mul_pd(hflowMask, qDenomVecPD, q0absVecPD);

		hflowPowVecPD = _mm512_pow_pd(hflowVecPD, powerVecPD);
		qDenomVecPD = _mm512_maskz_div_pd(hflowMask, qDenomVecPD, hflowPowVecPD);
		qDenomVecPD = _mm512_maskz_add_pd(hflowMask, onePD, qDenomVecPD);
		qVecPD = _mm512_maskz_div_pd(hflowMask, qNumVecPD, qDenomVecPD);
		qoldVecPD = qVecPD;
		qVecPD = _mm512_maskz_mul_pd(hflowMask, qVecPD, bflowVecPD);
		qVecPS = _mm512_cvtpd_ps(qVecPD);

		// Updates variable flow inertial: in m3/s
		_mm512_store_pd(Q2fl+i, qVecPD);
		_mm256_store_ps(QJ2+i, qVecPS);
	}

	return;
}
