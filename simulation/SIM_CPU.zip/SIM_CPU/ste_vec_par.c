#include <immintrin.h>
#include <omp.h>

void ste_vec_(double *Hfl, double *alpha, double *SRIO, double *g, double *dtteste, int *NC, int *NTH)
{
	__m512d hmaxflVecPD, minHflVecPD, mindtfloodVecPD, alphaVecPD, SRIOVecPD, gVecPD, numVecPD, denomVecPD, milVecPD, dtfloodVecPD;
	__m256 hmaxflVecPS;
    int i;
	int NCVec;
	int tid;

	tid = omp_get_thread_num();

	minHflVecPD = _mm512_set1_pd(0.001);
	mindtfloodVecPD = _mm512_set1_pd(*dtteste);
	alphaVecPD = _mm512_set1_pd(*alpha);
	gVecPD = _mm512_set1_pd(*g);
	milVecPD = _mm512_set1_pd(1000.0);
    NCVec = *NC-(*NC)%(8*(*NTH));
	#pragma omp for schedule(static)
    for(i = 0;i < NCVec;i+=8)
	{
		// MAX H to calculates the time-step of Inertial model:
	    // Correct if equal to zero:
		hmaxflVecPD = _mm512_load_pd(Hfl+i);
		hmaxflVecPS = _mm512_cvtpd_ps(hmaxflVecPD);
		hmaxflVecPD = _mm512_cvtps_pd(hmaxflVecPS);
		hmaxflVecPD = _mm512_max_pd(hmaxflVecPD, minHflVecPD);

	    // Compute time interval:
		SRIOVecPD = _mm512_load_pd(SRIO+i);
	    numVecPD = _mm512_mul_pd(alphaVecPD, SRIOVecPD);
	    numVecPD = _mm512_mul_pd(numVecPD, milVecPD);
	    denomVecPD = _mm512_mul_pd(gVecPD, hmaxflVecPD);
	    denomVecPD = _mm512_sqrt_pd(denomVecPD);

	    dtfloodVecPD = _mm512_div_pd(numVecPD, denomVecPD);

        mindtfloodVecPD = _mm512_min_pd(dtfloodVecPD, mindtfloodVecPD);
	}
    *dtteste = _mm512_reduce_min_pd(mindtfloodVecPD);

	return;
}
