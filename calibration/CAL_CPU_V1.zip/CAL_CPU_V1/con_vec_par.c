#include <immintrin.h>
#include <omp.h>
#include <stdbool.h>

void con_vec_(double *Q2flMON, double *Vol1, double *dtflood, float *QCEL2, double *Q2fl, float *E0agua, float *P, double *Area2, float *DTP, int *jtab, double *VTABREV, double *ZTABREV, double *ATABREV, float *ACEL, double *ZTABBAS, double *Yfl, double *Hfl, int *NC, int *NTH)
{
	__m512d Q2flMONVecPD, SumQupVecPD, Q2flVecPD, calc1PD, calc2PD, Vol2VecPD, Area2VecPD, DTPVecPD, QCEL2VecPD, E0aguaVecPD, PVecPD;
	__m512d dtfloodVecPD, Vol1VecPD, zeroVecPD, VTABREVpos0VecPD, VTABREVpos1VecPD, VolNumVecPD, VolDenomVecPD, VolVecPD;
	__m512d oneVecPD, ZTABREVpos0VecPD, ZTABREVpos1VecPD, yjtabVec1PD, yjtabVec2PD, yjtabVecPD, ATABREVpos0VecPD, ATABREVpos1VecPD;
	__m512d AreajtabVec1PD, AreajtabVec2PD, AreajtabVecPD, DACELVecPD, ZTABBASVecPD, ten2neg3VecPD, YflVecPD, HflVecPD;
	__m512d Vol2GEpos0andLEpos1VecPD, MILLIONVecPD, calc3PD;
	__m256 QCEL2VecPS, E0aguaVecPS, PVecPS, calc2PS, DTPVecPS, MILVecPS, calc3PS, Vol2VecPS, ACELVecPS, AreajtabVecPS;
	__m256i pos0VecIPS, pos1VecIPS, NCstepVecIPS, Vol2GEpos0andLEpos1VecIPS, oneVecIPS, twoVecIPS;
	__mmask8 Vol2GEpos0Mask, Vol2LEpos1Mask, Vol2LTpos0Mask, Vol2GTpos1Mask, Vol2GEpos0andLEpos1Mask;
	double stopSearch, SumQupPD[8];
	int NCstep[8], NCVec, nth;
    int i, j;
    int tid;

	nth = *NTH;
    tid = omp_get_thread_num();

	for(j = 0;j < 8;j++) NCstep[j] = *NC;

	DTPVecPS = _mm256_set1_ps(*DTP);
    DTPVecPD = _mm512_cvtps_pd(DTPVecPS);
	dtfloodVecPD = _mm512_set1_pd(*dtflood);
	zeroVecPD = _mm512_set1_pd(0.0);
	oneVecPD = _mm512_set1_pd(1.0);
	MILLIONVecPD = _mm512_set1_pd(1000000.0);
	MILVecPS = _mm256_set1_ps(1000.0);
	NCstepVecIPS = _mm256_load_epi32(NCstep);
	oneVecIPS = _mm256_set1_epi32(1);
	twoVecIPS = _mm256_set1_epi32(2);
	ten2neg3VecPD = _mm512_set1_pd(0.001);
	NCVec = *NC-(*NC)%(8*(*NTH));
    #pragma omp parallel for num_threads(nth) schedule(static) private(j,Q2flMONVecPD,SumQupPD,SumQupVecPD,QCEL2VecPS,QCEL2VecPD,Q2flVecPD,calc1PD,E0aguaVecPS,PVecPS,calc2PS,calc2PD,Area2VecPD,calc3PS,calc3PD,Vol1VecPD,Vol2VecPS,Vol2VecPD,pos0VecIPS,pos1VecIPS,VTABREVpos0VecPD,VTABREVpos1VecPD,Vol2GEpos0Mask,Vol2LEpos1Mask,Vol2GEpos0andLEpos1VecIPS,Vol2GEpos0andLEpos1Mask,VolNumVecPD,VolDenomVecPD,VolVecPD,ZTABREVpos0VecPD,ZTABREVpos1VecPD,yjtabVecPD,ATABREVpos0VecPD,ATABREVpos1VecPD,AreajtabVecPD,Vol2GEpos0andLEpos1VecPD,stopSearch,Vol2LTpos0Mask,Vol2GTpos1Mask,ACELVecPS,AreajtabVecPS,ZTABBASVecPD,YflVecPD,HflVecPD)
    for(i = 0;i < NCVec;i+=8)
	{
		//Sum of downstream IC flows
		for(j = 0;j < 8;j++) // each basin of 8
		{
            Q2flMONVecPD = _mm512_load_pd(Q2flMON+8*8*(i/8)+8*j);
			SumQupPD[j] = _mm512_reduce_add_pd(Q2flMONVecPD);
		}
		SumQupVecPD = _mm512_load_pd(SumQupPD);

		//Calculates the volume
		QCEL2VecPS = _mm256_load_ps(QCEL2+i);
        QCEL2VecPD = _mm512_cvtps_pd(QCEL2VecPS);
		Q2flVecPD = _mm512_load_pd(Q2fl+i);
		calc1PD = _mm512_add_pd(SumQupVecPD, QCEL2VecPD);
		calc1PD = _mm512_sub_pd(calc1PD, Q2flVecPD);
		calc1PD = _mm512_mul_pd(dtfloodVecPD, calc1PD);
		E0aguaVecPS = _mm256_load_ps(E0agua+i);
		PVecPS = _mm256_load_ps(P+i);
		calc2PS = _mm256_sub_ps(E0aguaVecPS, PVecPS);
        calc2PD = _mm512_cvtps_pd(calc2PS);
		Area2VecPD = _mm512_load_pd(Area2+i);
		calc2PD = _mm512_mul_pd(calc2PD, dtfloodVecPD);
		calc2PD = _mm512_mul_pd(calc2PD, Area2VecPD);
		calc2PD = _mm512_mul_pd(calc2PD, MILLIONVecPD);
		calc3PS = _mm256_mul_ps(DTPVecPS, MILVecPS);
        calc3PD = _mm512_cvtps_pd(calc3PS);
		calc2PD = _mm512_div_pd(calc2PD, calc3PD);
		calc1PD = _mm512_sub_pd(calc1PD, calc2PD);
		Vol1VecPD = _mm512_load_pd(Vol1+i);
		calc1PD = _mm512_add_pd(Vol1VecPD, calc1PD);
        Vol2VecPS = _mm512_cvtpd_ps(calc1PD);
        Vol2VecPD = _mm512_cvtps_pd(Vol2VecPS);
		Vol2VecPD = _mm512_max_pd(Vol2VecPD, zeroVecPD);

		// table search
		pos0VecIPS = _mm256_load_epi32(jtab+i);
		pos1VecIPS = _mm256_add_epi32(pos0VecIPS, NCstepVecIPS);
		do
		{
			// GE-LE part
			VTABREVpos0VecPD = _mm512_i32gather_pd(pos0VecIPS, VTABREV, 8);
			VTABREVpos1VecPD = _mm512_i32gather_pd(pos1VecIPS, VTABREV, 8);

			// If the channel (+floodplain) volume is between actual and next index of stage-area-volume table:
			Vol2GEpos0Mask = _mm512_cmple_pd_mask(VTABREVpos0VecPD, Vol2VecPD);
			Vol2LEpos1Mask = _mm512_cmple_pd_mask(Vol2VecPD, VTABREVpos1VecPD);

			Vol2GEpos0andLEpos1VecIPS = _mm256_set1_epi32(0);
			Vol2GEpos0andLEpos1VecIPS = _mm256_maskz_add_epi32(Vol2GEpos0Mask, Vol2GEpos0andLEpos1VecIPS, oneVecIPS);
			Vol2GEpos0andLEpos1VecIPS = _mm256_maskz_add_epi32(Vol2LEpos1Mask, Vol2GEpos0andLEpos1VecIPS, oneVecIPS);
			Vol2GEpos0andLEpos1Mask = _mm256_cmpeq_epi32_mask(Vol2GEpos0andLEpos1VecIPS, twoVecIPS);

			// Finds the % over the actual index of stage-area-volume table:
			VolNumVecPD = _mm512_maskz_sub_pd(Vol2GEpos0andLEpos1Mask, Vol2VecPD, VTABREVpos0VecPD);
			VolDenomVecPD = _mm512_maskz_sub_pd(Vol2GEpos0andLEpos1Mask, VTABREVpos1VecPD, VTABREVpos0VecPD);
			VolVecPD = _mm512_maskz_div_pd(Vol2GEpos0andLEpos1Mask, VolNumVecPD, VolDenomVecPD);

			// Interpolates values based on % above:
			ZTABREVpos0VecPD = _mm512_i32gather_pd(pos0VecIPS, ZTABREV, 8);
			ZTABREVpos1VecPD = _mm512_i32gather_pd(pos1VecIPS, ZTABREV, 8);

			yjtabVecPD = _mm512_maskz_sub_pd(Vol2GEpos0andLEpos1Mask, ZTABREVpos1VecPD, ZTABREVpos0VecPD);
			yjtabVecPD = _mm512_maskz_mul_pd(Vol2GEpos0andLEpos1Mask, yjtabVecPD, VolVecPD);
			yjtabVecPD = _mm512_maskz_add_pd(Vol2GEpos0andLEpos1Mask, ZTABREVpos0VecPD, yjtabVecPD);

			ATABREVpos0VecPD = _mm512_i32gather_pd(pos0VecIPS, ATABREV, 8);
			ATABREVpos1VecPD = _mm512_i32gather_pd(pos1VecIPS, ATABREV, 8);

			AreajtabVecPD = _mm512_maskz_sub_pd(Vol2GEpos0andLEpos1Mask, ATABREVpos1VecPD, ATABREVpos0VecPD);
			AreajtabVecPD = _mm512_maskz_mul_pd(Vol2GEpos0andLEpos1Mask, AreajtabVecPD, VolVecPD);
			AreajtabVecPD = _mm512_maskz_add_pd(Vol2GEpos0andLEpos1Mask, ATABREVpos0VecPD, AreajtabVecPD);

			Vol2GEpos0andLEpos1VecPD = _mm512_cvtepi32_pd(Vol2GEpos0andLEpos1VecIPS);
			stopSearch = _mm512_reduce_add_pd(Vol2GEpos0andLEpos1VecPD);
			if(stopSearch == 16.0) break;

			// LT part
			Vol2LTpos0Mask = _mm512_cmplt_pd_mask(Vol2VecPD, VTABREVpos0VecPD);
			pos0VecIPS = _mm256_mask_sub_epi32(pos0VecIPS, Vol2LTpos0Mask, pos0VecIPS, NCstepVecIPS);
			pos1VecIPS = _mm256_mask_sub_epi32(pos1VecIPS, Vol2LTpos0Mask, pos1VecIPS, NCstepVecIPS);

			// GT part
			Vol2GTpos1Mask = _mm512_cmplt_pd_mask(VTABREVpos1VecPD, Vol2VecPD);
			pos0VecIPS = _mm256_mask_add_epi32(pos0VecIPS, Vol2GTpos1Mask, pos0VecIPS, NCstepVecIPS);
			pos1VecIPS = _mm256_mask_add_epi32(pos1VecIPS, Vol2GTpos1Mask, pos1VecIPS, NCstepVecIPS);
		}
		while(true);

		_mm256_store_epi32(jtab+i, pos0VecIPS);

		ACELVecPS = _mm256_load_ps(ACEL+i);
        AreajtabVecPS = _mm512_cvtpd_ps(AreajtabVecPD);
		AreajtabVecPS = _mm256_min_ps(AreajtabVecPS, ACELVecPS);
        AreajtabVecPD = _mm512_cvtps_pd(AreajtabVecPS);
		_mm512_store_pd(Area2+i, AreajtabVecPD);

		//Updates variables:
		ZTABBASVecPD = _mm512_load_pd(ZTABBAS+i);
		ZTABBASVecPD = _mm512_add_pd(ZTABBASVecPD, ten2neg3VecPD);
		YflVecPD = _mm512_max_pd(yjtabVecPD, ZTABBASVecPD);
		_mm512_store_pd(Yfl+i, YflVecPD);

		//Calculates depth
		ZTABBASVecPD = _mm512_sub_pd(ZTABBASVecPD, ten2neg3VecPD);
		HflVecPD = _mm512_sub_pd(YflVecPD, ZTABBASVecPD);
		_mm512_store_pd(Hfl+i, HflVecPD);

		//Updates the volume
		_mm512_store_pd(Vol1+i, Vol2VecPD);
	}

	return;
}
