#include <immintrin.h>
#include <omp.h>

void condinic_vec_(int *IBAC, int *NSUBT, int *CELJUS, float *W, float *WM, float *VBAS, float *QESP, float *ACEL, float *CB, float *VINT, float *VSUP, float *QBAS, float *CI, float *TIND, float *QINT, float *CS, float *QSUP, float *QCEL2, float *QCEL1, float *QM2, float *QJ2, int *NC, int *NB, int *NU)
{
	__m512d zeroVecPD;
	__m256 zeroVecPS, secsVecPS, WMVecPS, WVecPS, WMfracVecPS, QESPVecPS, ACELVecPS, CBVecPS, TKVecPS, VBASVecPS, QBASVecPS, CIVecPS, TINDVecPS;
	__m256 calcVecPS, QINTVecPS, VINTVecPS, CSVecPS, QSUPVecPS, VSUPVecPS, QCEL2VecPS, QM2VecPS, QJ2VecPS, QM2JUSVecPS;
	__m256i IBVecIPS, IUVecIPS, IBIUVecIPS, oneVecIPS, NSUBTVecIPS, zeroVecIPS, JUSVecIPS, NSUBTGT0JUSVecIPS, NSUBTLE0JUSVecIPS, twoVecIPS;
	__mmask8 loadMask, NSUBTMask, JUSMask, NSUBTGT0JUSMask, NSUBTLE0JUSMask;
	int NCVec, IC, IU;

	zeroVecPD = _mm512_set1_pd(0.0);
	zeroVecPS = _mm256_set1_ps(0.0);
	secsVecPS = _mm256_set1_ps(3600.0);
	WMfracVecPS = _mm256_set1_ps(0.4);
	zeroVecIPS = _mm256_set1_epi32(0);
	oneVecIPS = _mm256_set1_epi32(1);
	twoVecIPS = _mm256_set1_epi32(2);
	loadMask = _mm512_cmpeq_pd_mask(zeroVecPD, zeroVecPD);
	NCVec = *NC-(*NC)%8;
        for(IC = 0;IC < NCVec;IC+=8)
	{
		// Sub-catchment
		IBVecIPS = _mm256_load_epi32(IBAC+IC);
		IBVecIPS = _mm256_mask_sub_epi32(IBVecIPS, loadMask, IBVecIPS, oneVecIPS);

		// Soil moisture
		for(IU = 0;IU < *NU;IU++)
		{
			IUVecIPS = _mm256_set1_epi32(IU*(*NB));
			IBIUVecIPS = _mm256_mask_add_epi32(IBVecIPS, loadMask, IBVecIPS, IUVecIPS);
			WMVecPS = _mm256_mmask_i32gather_ps(zeroVecPS, loadMask, IBIUVecIPS, WM, 4);

			// The soil has 40% of water at the beginning of simulation
			WVecPS = _mm256_mul_ps(WMVecPS, WMfracVecPS);
			_mm256_store_ps(W+IU*(*NC)+IC, WVecPS);
		}

		// Volumes in Reservoirs
		QESPVecPS = _mm256_mmask_i32gather_ps(zeroVecPS, loadMask, IBVecIPS, QESP, 4);
		ACELVecPS = _mm256_load_ps(ACEL+IC);
		CBVecPS = _mm256_mmask_i32gather_ps(zeroVecPS, loadMask, IBVecIPS, CB, 4);
		calcVecPS = _mm256_mul_ps(QESPVecPS, ACELVecPS);
		calcVecPS = _mm256_mul_ps(calcVecPS, CBVecPS);
		VBASVecPS = _mm256_mul_ps(calcVecPS, secsVecPS);
		_mm256_store_ps(VBAS+IC, VBASVecPS);
		_mm256_store_ps(VINT+IC, zeroVecPS);
		_mm256_store_ps(VSUP+IC, zeroVecPS);

		// Flow in reservoirs
		// Underground flow
		TKVecPS = _mm256_mul_ps(CBVecPS, secsVecPS);
		QBASVecPS = _mm256_div_ps(VBASVecPS, TKVecPS);
		_mm256_store_ps(QBAS+IC, QBASVecPS);
		// Subsurface flow
		//CIVecPS = _mm256_mmask_i32gather_ps(zeroVecPS, loadMask, IBVecIPS, CI, 4);
		//TINDVecPS = _mm256_load_ps(TIND+IC);
		//TKVecPS = _mm256_mul_ps(CIVecPS, TINDVecPS);
		//VINTVecPS = _mm256_load_ps(VINT+IC);
		//QINTVecPS = _mm256_div_ps(VINTVecPS, TKVecPS);
		_mm256_store_ps(QINT+IC, zeroVecPS);
		// Runoff
		//CSVecPS = _mm256_mmask_i32gather_ps(zeroVecPS, loadMask, IBVecIPS, CS, 4);
                //TKVecPS = _mm256_mul_ps(CSVecPS, TINDVecPS);
                //VSUPVecPS = _mm256_load_ps(VSUP+IC);
                //QSUPVecPS = _mm256_div_ps(VSUPVecPS, TKVecPS);
		_mm256_store_ps(QSUP+IC, zeroVecPS);

		// Sum the flows generated in each unit-catchment
		//calcVecPS = _mm256_add_ps(QBASVecPS, QINTVecPS);
		//QCEL2VecPS = _mm256_add_ps(calcVecPS, QSUPVecPS);
		QCEL2VecPS = QBASVecPS;
		_mm256_store_ps(QCEL2+IC, QCEL2VecPS);
		_mm256_store_ps(QCEL1+IC, QCEL2VecPS);

		NSUBTVecIPS = _mm256_load_epi32(NSUBT+IC);
		JUSVecIPS = _mm256_load_epi32(CELJUS+IC);
		JUSVecIPS = _mm256_mask_sub_epi32(JUSVecIPS, loadMask, JUSVecIPS, oneVecIPS);
		JUSMask = _mm256_cmpge_epi32_mask(JUSVecIPS, zeroVecIPS);
		// NSUBT(IC).GT.0
		// unit-catchment with river
		NSUBTMask = _mm256_cmpgt_epi32_mask(NSUBTVecIPS, zeroVecIPS);
		NSUBTGT0JUSVecIPS = _mm256_set1_epi32(0);
		NSUBTGT0JUSVecIPS = _mm256_maskz_add_epi32(NSUBTMask, NSUBTGT0JUSVecIPS, oneVecIPS);
		NSUBTGT0JUSVecIPS = _mm256_maskz_add_epi32(JUSMask, NSUBTGT0JUSVecIPS, oneVecIPS);
		NSUBTGT0JUSMask = _mm256_cmpeq_epi32_mask(NSUBTGT0JUSVecIPS, twoVecIPS);
		// Accumulates flow
		QM2VecPS = _mm256_load_ps(QM2+IC);
		QM2VecPS = _mm256_mask_add_ps(QM2VecPS, NSUBTMask, QM2VecPS, QCEL2VecPS);
		_mm256_mask_store_ps(QM2+IC, NSUBTMask, QM2VecPS);
		// Constant flow in river
		QJ2VecPS = QM2VecPS;
		_mm256_mask_store_ps(QJ2+IC, NSUBTMask, QJ2VecPS);
		// Continuity
		QM2JUSVecPS = _mm256_mmask_i32gather_ps(zeroVecPS, NSUBTGT0JUSMask, JUSVecIPS, QM2, 4);
		QM2JUSVecPS = _mm256_mask_add_ps(QM2JUSVecPS, NSUBTGT0JUSMask, QM2JUSVecPS, QJ2VecPS);
		_mm256_mask_i32scatter_ps(QM2, NSUBTGT0JUSMask, JUSVecIPS, QM2JUSVecPS, 4);
		// NSUBT(IC).LE.0
		// unit-catchment without river
		NSUBTMask = _mm256_cmple_epi32_mask(NSUBTVecIPS, zeroVecIPS);
		NSUBTLE0JUSVecIPS = _mm256_set1_epi32(0);
		NSUBTLE0JUSVecIPS = _mm256_maskz_add_epi32(NSUBTMask, NSUBTLE0JUSVecIPS, oneVecIPS);
		NSUBTLE0JUSVecIPS = _mm256_maskz_add_epi32(JUSMask, NSUBTLE0JUSVecIPS, oneVecIPS);
		NSUBTLE0JUSMask = _mm256_cmpeq_epi32_mask(NSUBTLE0JUSVecIPS, twoVecIPS);
		_mm256_mask_store_ps(QJ2+IC, NSUBTMask, QCEL2VecPS);
		_mm256_mask_store_ps(QM2+IC, NSUBTMask, QCEL2VecPS);
		// Continuity
		QM2JUSVecPS = _mm256_mmask_i32gather_ps(zeroVecPS, NSUBTLE0JUSMask, JUSVecIPS, QM2, 4);
		QM2JUSVecPS = _mm256_mask_add_ps(QM2JUSVecPS, NSUBTLE0JUSMask, QM2JUSVecPS, QCEL2VecPS);
		_mm256_mask_i32scatter_ps(QM2, NSUBTLE0JUSMask, JUSVecIPS, QM2JUSVecPS, 4);
	}

	return;
}
