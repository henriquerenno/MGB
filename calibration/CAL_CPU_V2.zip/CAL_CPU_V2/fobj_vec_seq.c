#include <immintrin.h>
#include <omp.h>

void fobj_vec_(float *QOBSIT, float *QRIT, float *SQDES, float *SOMQ, float *SQLOG, float *SOLOG, float *SOMACAL, float *SOMAOBS, int *ITVAL, int *NT)
{
	__m256 zeroVecPS, QOBSITVecPS, QRITVecPS, SOMAOBSVecPS, SOMACALVecPS, SOMALOGSVecPS, SOMALCALVecPS, ten2neg4VecPS, LOGQOBSITVecPS;
	__m256 LOGQRITVecPS, SOMAOBSPermVecPS, TOTSOMAOBSVecPS, SOMACALPermVecPS, TOTSOMACALVecPS, SOMALOGSPermVecPS, TOTSOMALOGSVecPS;
	__m256 SOMALCALPermVecPS, TOTSOMALCALVecPS, SQDESVecPS, SQDESPermVecPS, TOTSQDESVecPS, pow2VecPS, XMOBSVecPS, SOMQVecPS, SOMQPermVecPS;
	__m256 TOTSOMQVecPS, SQLOGVecPS, SQLOGPermVecPS, TOTSQLOGVecPS, SOLOGVecPS, SOLOGPermVecPS, TOTSOLOGVecPS, XLOGSVecPS;
	__m256i permPosVecIPS;
	__m512d ITVALVecPD, zeroVecPD, oneVecPD, mask1VecPD, mask2VecPD;
	__mmask8 QOBSITGE0Mask;
	double ITVAL_d, SOMAOBS_d, SOMACAL_d, SOMALOGS_d, SOMALCAL_d;
	double mask1[8] = {1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0}, mask2[8] = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0};
	float XMOBS, XLOGS, SOMAOBS_f[8], SOMALOGS_f[8], ITVAL_f, val_f[8];
	int NTVec, IT, permPos[8] = {4, 5, 6, 7, 0, 1, 2, 3};
	__mmask8 SOMAMask;

	printf("%d\n", *NT);

	zeroVecPS = _mm256_set1_ps(0.0);
	ten2neg4VecPS = _mm256_set1_ps(0.0001);
	pow2VecPS = _mm256_set1_ps(2.0);
	zeroVecPD = _mm512_set1_pd(0.0);
	oneVecPD = _mm512_set1_pd(1.0);
	TOTSOMAOBSVecPS = zeroVecPS;
	TOTSOMACALVecPS = zeroVecPS;
	TOTSOMALOGSVecPS = zeroVecPS;
	TOTSOMALCALVecPS = zeroVecPS;
	permPosVecIPS = _mm256_load_epi32(permPos);
	mask1VecPD = _mm512_load_pd(mask1);
	mask2VecPD = _mm512_load_pd(mask2);
	SOMAMask = _mm512_cmpeq_pd_mask(mask1VecPD, mask2VecPD);
	ITVAL_d = 0.0;
	NTVec = *NT;
	//NTVec = *NT-(*NT)%8;
        for(IT = 0;IT < NTVec;IT+=8)
	{
		QOBSITVecPS = _mm256_load_ps(QOBSIT+IT);
		QOBSITGE0Mask = _mm256_cmp_ps_mask(QOBSITVecPS, zeroVecPS, 13); // 13: _CMP_GE_OS
		SOMAOBSVecPS = zeroVecPS;
		SOMAOBSVecPS = _mm256_maskz_add_ps(QOBSITGE0Mask, SOMAOBSVecPS, QOBSITVecPS);
		SOMAOBSPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SOMAOBSVecPS);
		SOMAOBSVecPS = _mm256_hadd_ps(SOMAOBSVecPS, SOMAOBSPermVecPS);
		SOMAOBSVecPS = _mm256_hadd_ps(SOMAOBSVecPS, zeroVecPS);
		SOMAOBSVecPS = _mm256_hadd_ps(SOMAOBSVecPS, zeroVecPS);
		TOTSOMAOBSVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSOMAOBSVecPS, SOMAOBSVecPS);

		QRITVecPS = _mm256_load_ps(QRIT+IT);
		SOMACALVecPS = zeroVecPS;
		SOMACALVecPS = _mm256_maskz_add_ps(QOBSITGE0Mask, SOMACALVecPS, QRITVecPS);
		SOMACALPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SOMACALVecPS);
		SOMACALVecPS = _mm256_hadd_ps(SOMACALVecPS, SOMACALPermVecPS);
		SOMACALVecPS = _mm256_hadd_ps(SOMACALVecPS, zeroVecPS);
		SOMACALVecPS = _mm256_hadd_ps(SOMACALVecPS, zeroVecPS);
		TOTSOMACALVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSOMACALVecPS, SOMACALVecPS);

		// Sums a small value to avoid undefinition in log(0.0)
		LOGQOBSITVecPS = _mm256_mask_add_ps(ten2neg4VecPS, QOBSITGE0Mask, QOBSITVecPS, ten2neg4VecPS);
		LOGQOBSITVecPS = _mm256_log_ps(LOGQOBSITVecPS);
		SOMALOGSVecPS = zeroVecPS;
		SOMALOGSVecPS = _mm256_maskz_add_ps(QOBSITGE0Mask, SOMALOGSVecPS, LOGQOBSITVecPS);
		SOMALOGSPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SOMALOGSVecPS);
		SOMALOGSVecPS = _mm256_hadd_ps(SOMALOGSVecPS, SOMALOGSPermVecPS);
		SOMALOGSVecPS = _mm256_hadd_ps(SOMALOGSVecPS, zeroVecPS);
		SOMALOGSVecPS = _mm256_hadd_ps(SOMALOGSVecPS, zeroVecPS);
		TOTSOMALOGSVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSOMALOGSVecPS, SOMALOGSVecPS);

		LOGQRITVecPS = _mm256_mask_add_ps(ten2neg4VecPS, QOBSITGE0Mask, QRITVecPS, ten2neg4VecPS);
		LOGQRITVecPS = _mm256_log_ps(LOGQRITVecPS);
		SOMALCALVecPS = zeroVecPS;
		SOMALCALVecPS = _mm256_maskz_add_ps(QOBSITGE0Mask, SOMALCALVecPS, LOGQRITVecPS);
		SOMALCALPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SOMALCALVecPS);
		SOMALCALVecPS = _mm256_hadd_ps(SOMALCALVecPS, SOMALCALPermVecPS);
		SOMALCALVecPS = _mm256_hadd_ps(SOMALCALVecPS, zeroVecPS);
		SOMALCALVecPS = _mm256_hadd_ps(SOMALCALVecPS, zeroVecPS);
		TOTSOMALCALVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSOMALCALVecPS, SOMALCALVecPS);

		ITVALVecPD = zeroVecPD;
		ITVALVecPD = _mm512_maskz_add_pd(QOBSITGE0Mask, ITVALVecPD, oneVecPD);
		ITVAL_d += _mm512_mask_reduce_add_pd(QOBSITGE0Mask, ITVALVecPD);
	}

	_mm256_store_ps(SOMAOBS_f, TOTSOMAOBSVecPS);
	_mm256_store_ps(SOMALOGS_f, TOTSOMALOGSVecPS);
	ITVAL_f = (float)(ITVAL_d);
	XMOBS = SOMAOBS_f[0]/ITVAL_f;
	XLOGS = SOMALOGS_f[0]/ITVAL_f;

	XMOBSVecPS = _mm256_set1_ps(XMOBS);
	XLOGSVecPS = _mm256_set1_ps(XLOGS);
	TOTSQDESVecPS = zeroVecPS;
        for(IT = 0;IT < NTVec;IT+=8)
	{
		QOBSITVecPS = _mm256_load_ps(QOBSIT+IT);
		QOBSITGE0Mask = _mm256_cmp_ps_mask(QOBSITVecPS, zeroVecPS, 13); // 13: _CMP_GE_OS
		QRITVecPS = _mm256_load_ps(QRIT+IT);

		SQDESVecPS = _mm256_maskz_sub_ps(QOBSITGE0Mask, QOBSITVecPS, QRITVecPS);
		SQDESVecPS = _mm256_pow_ps(SQDESVecPS, pow2VecPS);
		SQDESPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SQDESVecPS);
		SQDESVecPS = _mm256_hadd_ps(SQDESVecPS, SQDESPermVecPS);
		SQDESVecPS = _mm256_hadd_ps(SQDESVecPS, zeroVecPS);
		SQDESVecPS = _mm256_hadd_ps(SQDESVecPS, zeroVecPS);
		TOTSQDESVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSQDESVecPS, SQDESVecPS);

		SOMQVecPS = _mm256_maskz_sub_ps(QOBSITGE0Mask, QOBSITVecPS, XMOBSVecPS);
		SOMQVecPS = _mm256_pow_ps(SOMQVecPS, pow2VecPS);
		SOMQPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SOMQVecPS);
		SOMQVecPS = _mm256_hadd_ps(SOMQVecPS, SOMQPermVecPS);
		SOMQVecPS = _mm256_hadd_ps(SOMQVecPS, zeroVecPS);
		SOMQVecPS = _mm256_hadd_ps(SOMQVecPS, zeroVecPS);
		TOTSOMQVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSOMQVecPS, SOMQVecPS);

		LOGQOBSITVecPS = _mm256_mask_add_ps(ten2neg4VecPS, QOBSITGE0Mask, QOBSITVecPS, ten2neg4VecPS);
		LOGQOBSITVecPS = _mm256_log_ps(LOGQOBSITVecPS);
		LOGQRITVecPS = _mm256_mask_add_ps(ten2neg4VecPS, QOBSITGE0Mask, QRITVecPS, ten2neg4VecPS);
		LOGQRITVecPS = _mm256_log_ps(LOGQRITVecPS);
		SQLOGVecPS = _mm256_maskz_sub_ps(QOBSITGE0Mask, LOGQOBSITVecPS, LOGQRITVecPS);
		SQLOGVecPS = _mm256_pow_ps(SQLOGVecPS, pow2VecPS);
		SQLOGPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SQLOGVecPS);
		SQLOGVecPS = _mm256_hadd_ps(SQLOGVecPS, SQLOGPermVecPS);
		SQLOGVecPS = _mm256_hadd_ps(SQLOGVecPS, zeroVecPS);
		SQLOGVecPS = _mm256_hadd_ps(SQLOGVecPS, zeroVecPS);
		TOTSQLOGVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSQLOGVecPS, SQLOGVecPS);

		SOLOGVecPS = LOGQOBSITVecPS;
		SOLOGVecPS = _mm256_maskz_sub_ps(QOBSITGE0Mask, SOLOGVecPS, XLOGSVecPS);
		SOLOGVecPS = _mm256_pow_ps(SOLOGVecPS, pow2VecPS);
		SOLOGPermVecPS = _mm256_permutexvar_ps(permPosVecIPS, SOLOGVecPS);
		SOLOGVecPS = _mm256_hadd_ps(SOLOGVecPS, SOLOGPermVecPS);
		SOLOGVecPS = _mm256_hadd_ps(SOLOGVecPS, zeroVecPS);
		SOLOGVecPS = _mm256_hadd_ps(SOLOGVecPS, zeroVecPS);
		TOTSOLOGVecPS = _mm256_maskz_add_ps(SOMAMask, TOTSOLOGVecPS, SOLOGVecPS);
	}

	_mm256_store_ps(val_f, TOTSQDESVecPS);
	*SQDES = val_f[0];
	_mm256_store_ps(val_f, TOTSOMQVecPS);
	*SOMQ = val_f[0];
	_mm256_store_ps(val_f, TOTSQLOGVecPS);
	*SQLOG = val_f[0];
	_mm256_store_ps(val_f, TOTSOLOGVecPS);
	*SOLOG = val_f[0];
	_mm256_store_ps(val_f, TOTSOMACALVecPS);
	*SOMACAL = val_f[0];
	_mm256_store_ps(val_f, TOTSOMAOBSVecPS);
	*SOMAOBS = val_f[0];
	*ITVAL = (int)(ITVAL_f);

	return;
}
